package entities;

public class AreaTerreno {
	
	public double areaTotal;
	
	public  void retorneAreaTotal(double base, double altura) {
		areaTotal = base * altura;
		
						
	}

}
