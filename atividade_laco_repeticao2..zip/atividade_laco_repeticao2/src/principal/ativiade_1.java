package principal;

import java.util.Scanner;

public class ativiade_1 {

	public static void main(String[] args) {
//		Fa�a um programa que receba o tipo de opera��o a ser realizada (soma, divis�o, multiplica��o, subtra��o) e imprima a tabuada desse n�mero. 
//		ex.: 1x2 = 2, 1x3 = 3...
				
		Scanner sc = new Scanner(System.in);
		
        System.out.print("Digite o n�mero para a tabuada: ");
        String operacao = sc.nextLine();
        int numero = sc.nextInt();
        
        if (operacao.equals("soma")) {
            for (int i = 1; i <= 10; i++) {
                int resultado = numero + i;
                System.out.println(numero + " + " + i + " = " + resultado);
            }
        } else if (operacao.equals("subtra��o")) {
            for (int i = 1; i <= 10; i++) {
                int resultado = numero - i;
                System.out.println(numero + " - " + i + " = " + resultado);
            }
        } else if (operacao.equals("multiplica��o")) {
            for (int i = 1; i <= 10; i++) {
                int resultado = numero * i;
                System.out.println(numero + " x " + i + " = " + resultado);
            }
        } else if (operacao.equals("divis�o")) {
            for (int i = 1; i <= 10; i++) {
                int resultado = numero / i;
                System.out.println(numero + " / " + i + " = " + resultado);
            }
        } else {
            System.out.println("Opera��o inv�lida!");
        }
	}
}
